my_package 

Author : Anand Parikh
Roll no.: 20CS10007

Software Engineering Lab Spring 2021
Python DS assignment 

Enjoy!

Note : After making changes to any source file in the package, follow these steps to update it:

1. Update version in setup.py
2. Go to folder with setup.py, open powershell and write : python setup.py sdist bdist_wheel
3. Go to "dist" folder, observe that a new .whl file of latest version is available
4. Open powershell and write : pip install <latest_wheel_file>
