import numpy as np
from PIL import Image,ImageDraw,ImageFont

def plot_visualization(pred, np_arr, r, g, b,show,idx,analysis,save_file=None):
    pred_boxes = pred[0]
    pred_masks = pred[1]
    pred_class = pred[2]
    pred_score = pred[3]

    full_mask = np.zeros(np_arr.shape)
    final_image = np_arr

    if len(pred[3]) < 3:
        for i in range(len(pred[3])):
            full_mask[i] = full_mask[i] + pred_masks[i]

    else:
        for i in range(3):
            full_mask[i] = full_mask[i] + pred_masks[i]

    final_image = final_image * 255
    final_image = np.transpose(final_image, (1, 2, 0))

    full_mask = full_mask * 255
    full_mask = np.transpose(full_mask, (1, 2, 0))

    final_image = final_image + full_mask * [r, g, b]

    PIL_image = Image.fromarray(final_image.astype('uint8'), 'RGB')

    draw = ImageDraw.Draw(PIL_image)
    font = ImageFont.truetype("arial.ttf",16)

    if len(pred[3]) < 3:
        for i in range(len(pred[3])):
            x1 = int(pred_boxes[i][0][0])
            y1 = int(pred_boxes[i][0][1])
            x2 = int(pred_boxes[i][1][0])
            y2 = int(pred_boxes[i][1][1])

            t = pred_class[i] + ", " + str(pred_score[i])

            draw.rectangle((x1,y1,x2,y2),fill = None,outline=(200,0,120),width=1)
            draw.text((x1,y1),t,font=font,fill = (0,0,255))

    else:
        for i in range(3):
            x1 = int(pred_boxes[i][0][0])
            y1 = int(pred_boxes[i][0][1])
            x2 = int(pred_boxes[i][1][0])
            y2 = int(pred_boxes[i][1][1])

            t = pred_class[i] + ", " + str(pred_score[i])

            draw.rectangle((x1, y1, x2, y2), fill=None, outline=(200, 0, 120), width=1)
            draw.text((x1, y1), t, font=font, fill=(0,0,255))

    if show :
         PIL_image.show()

    file = str(save_file)
    PIL_image.save(file+"/{}_v2.jpg".format(idx))

    return PIL_image











